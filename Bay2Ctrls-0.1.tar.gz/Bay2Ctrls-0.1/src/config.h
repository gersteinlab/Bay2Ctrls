/* confdefs.h */
#define PACKAGE_NAME "Bay2Ctrls"
#define PACKAGE_TARNAME "Bay2Ctrls"
#define PACKAGE_VERSION "1.7"
#define PACKAGE_STRING "Bay2Ctrls 1.7"
#define PACKAGE_BUGREPORT ""
#define PACKAGE_URL ""
#define HAVE_LIBBZ2 1
#define HAVE_BOOST 1
